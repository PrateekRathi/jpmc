﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Game
    {
        private int[] noOfRolls = new int[21];
        private int currentRoll = 0;
        private const int originalNoOfPins = 10;

        private bool isSpare(int framePosition)
        {
            return (noOfRolls[framePosition] + noOfRolls[framePosition + 1]) == originalNoOfPins;
        }

        private bool isStrike(int framePosition)
        {
            return noOfRolls[framePosition] == originalNoOfPins;
        }

        public void Roll(int pins)
        {
            noOfRolls[currentRoll++] = pins;
        }

        public void Roll(int[] multiplePins)
        {
            Array.Copy(multiplePins,noOfRolls,multiplePins.Length);
        }

        public int GetScore()
        {
            int score = 0;
            int framePosition = 0;
            for (int frame = 0; frame < 10; frame++)
            {
                if (isSpare(framePosition))
                {
                    score += originalNoOfPins + noOfRolls[framePosition + 2];
                    framePosition += 2;
                }
                else if (isStrike(framePosition))
                {
                    score += originalNoOfPins + noOfRolls[framePosition + 1] + noOfRolls[framePosition + 2];
                    framePosition++;
                }
                else
                {
                    score += noOfRolls[framePosition] + noOfRolls[framePosition + 1];
                    framePosition += 2;
                }
            }
            return score;
        }
    }
}
