﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        private Game _game;

        public GameFixture()
        {
            _game = new Game();
        }

        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        {
            Roll(_game, 0, 20);
            Assert.AreEqual(0, _game.GetScore());
        }

        private void Roll(Game game, int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                game.Roll(pins);
            }
        }

        [TestMethod]
        public void Test_Normal_Game()
        {
            _game.Roll(new int[] { 10, 9, 1, 5, 5, 7, 2, 10, 10, 10, 9, 0, 8, 2, 9, 1, 10 });
            var score = _game.GetScore();
            Assert.AreEqual(187, score);
        }

        [TestMethod]
        public void Test_Game_With_3_Strike_At_End()
        {
            _game.Roll(new int[] { 10, 9, 1, 5, 5, 7, 2, 10, 10, 10, 9, 0, 8, 2, 10, 10, 10 });
            Assert.AreEqual(198, _game.GetScore());
        }

        [TestMethod]
        public void Test_All_Strike()
        {
            Roll(_game, 10, 12);
            Assert.AreEqual(300, _game.GetScore());
        }

        [TestMethod]
        public void Test_All_Spare()
        {
            _game.Roll(new int[] { 7,3,5,5,6,4,9,1,2,8,9,1,3,7,9,1,1,9,3,7,6});
            Assert.AreEqual(153, _game.GetScore());
        }
    }
}
